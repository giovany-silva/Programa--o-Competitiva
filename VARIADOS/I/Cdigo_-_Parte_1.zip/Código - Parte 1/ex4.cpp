#include <iostream>
#include <list>
#include <string>
using namespace std;

int main() {
    list<string> nomes;
    list<string>::iterator it;

    // Inserindo dados(back, front, random)
    nomes.push_back("Joao");
    nomes.push_back("Paulo");
    nomes.push_front("Bruno");

    it = nomes.begin();
    nomes.insert(it, "Bruno");
    ++it; ++it;
    nomes.insert(it, "Edmilson");

    cout << "Lista de Nomes: " << endl;
    for(it = nomes.begin(); it != nomes.end(); ++it)
        cout << *it << endl;

    // Removendo todos os Robertos
    nomes.remove("Bruno");
    cout << "\nLista de Nomes: " << endl;
    for(it = nomes.begin(); it != nomes.end(); ++it)
        cout << *it << endl;

    return 0;
}
