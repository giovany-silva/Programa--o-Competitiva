#include <stdio.h>
#include <deque>
using namespace std;

int main() {
    deque<int> dados;
    deque<int>::iterator it;

    // Podemos inserir elementos no inicio e fim da fila
    dados.push_front(1);
    dados.push_front(2);
    dados.push_front(3);
    dados.push_back(9);
    dados.push_back(10);

    printf("Tamanho da deque: %d.\n", dados.size());

    printf("Elementos: ");
    for(it = dados.begin(); it < dados.end(); ++it)
        printf("%d ", *it);
    printf("\n");

    // Acesso aleatorio
    printf("Terceiro elemento: %d \n", dados[2]);

    // tambem podemos remover elementos das duas extremidades
    dados.pop_back();
    dados.pop_front();

    printf("Elementos: ");
    for(it = dados.begin(); it < dados.end(); ++it)
        printf("%d ", *it);
    printf("\n");

    return 0;
}
