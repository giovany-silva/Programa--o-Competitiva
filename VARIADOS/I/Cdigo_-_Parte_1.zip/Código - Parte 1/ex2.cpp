#include <vector>
#include <cstdio>
using namespace std;

int main() {
    vector<float> medidas;
    vector<float>::iterator it;

    printf("Tamanho Inicial: %d\n", medidas.size());
    medidas.push_back(15.6);
    medidas.push_back(23.6);
    medidas.push_back(2.9);
    medidas.push_back(17.3);
    medidas.push_back(11.9);
    medidas.push_back(7.7);
    printf("Tamanho Final: %d\n", medidas.size());

    printf("\nSegundo item: %.1f \n", medidas[1]);
    printf("Quinto item: %.1f \n", medidas[4]);
    printf("Terceiro item: %.1f \n", medidas.at(2));
    printf("Primeiro item: %.1f \n", medidas.at(0));

    printf("\nVetor Inicial: ");
    for(it = medidas.begin(); it < medidas.end(); ++it)
        printf("%.1f ", *it);
    printf("\n");

    // Podemos apagar itens (precisamos do iterador
    medidas.erase(medidas.begin()); // primeiro item
    medidas.erase(medidas.begin() + 2); // terceiro item

    printf("Vetor Resultante: ");
    for(it = medidas.begin(); it < medidas.end(); ++it)
        printf("%.1f ", *it);
    printf("\n");

    return 0;
}
