#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> idades;
    vector<int>::iterator it;
    idades.push_back(20);
    idades.push_back(17);
    idades.push_back(21);

    printf("Vetor Desordenado: ");
    for(it = idades.begin(); it != idades.end(); ++it)
        printf("%d ", *it);
    sort(idades.begin(), idades.end());
    printf("\nVetor Ordenado: ");
    for(it = idades.begin(); it != idades.end(); ++it)
        printf("%d ", *it);
    return 0;
}
