#include <iostream>
#include <algorithm>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace std;

// Funcao de comparacao
bool compare(int i, int j) {
    return (i < j);
}

int main() {
    vector<int> numeros;
    srand(time(NULL));

    // Sorteando numeros aleatorios e imprimindo
    cout << "Vetor aleatorio: ";
    for(int i = 0; i < 10; i++) {
        int x = rand()%100;
        numeros.push_back(x);
        cout << x << " ";
    }
    cout << endl;

    // Ordenando primeira metade (heap sort)
    partial_sort(numeros.begin(), numeros.begin()+5, numeros.end());
    cout << "Primeira metade ordenada: ";
    for(int i = 0; i < 10; i++)
        cout << numeros[i] << " ";
    cout << endl;

    // Ordenando segunda metade (sort normal)
    sort(numeros.begin() + 5, numeros.end());
    cout << "Segunda metade ordenada: ";
    for(int i = 0; i < 10; i++)
        cout << numeros[i] << " ";
    cout << endl;

    // Ordenando tudo (com funcao de comparacao e ordenacao estavel)
    stable_sort(numeros.begin(), numeros.end(), compare);
    cout << "Vetor ordenado: ";
    for(int i = 0; i < 10; i++)
        cout << numeros[i] << " ";
    cout << endl;

    return 0;
}
