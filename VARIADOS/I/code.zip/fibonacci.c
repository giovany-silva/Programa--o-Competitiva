#include <stdio.h>
#include <time.h>

// Implementacao recursiva
int fibo_recursivo(int n)
{
    if(n == 0) return 0;
    if(n == 1) return 1;

    return fibo_recursivo(n-1) + fibo_recursivo(n-2);
}

// implementacao iterativa
int fibo_iterativo(int n)
{
    int vetor[n], i;

    vetor[0] = 0;
    vetor[1] = 1;

    for(i = 2; i <= n; i++)
        vetor[i] = vetor[i-1] + vetor[i-2];

    return vetor[n];
}

int main()
{
    int n, resp;
    int tempo_ini, tempo_fin, tempo_ms;

    while(1) {
        printf("Entre com um valor de n (-1 para sair): ");
        scanf("%d", &n);

        if(n == -1) break;

        tempo_ini = (int) clock();
        resp = fibo_recursivo(n);
        tempo_fin = (int) clock();
        tempo_ms = ((tempo_fin - tempo_ini)*1000/CLOCKS_PER_SEC);
        printf("Fibonacci Recursivo: %d , em %d ms. \n", resp, tempo_ms);

        tempo_ini = (int) clock();
        resp = fibo_iterativo(n);
        tempo_fin = (int) clock();
        tempo_ms = ((tempo_fin - tempo_ini)*1000/CLOCKS_PER_SEC);
        printf("Fibonacci Iterativo: %d , em %d ms. \n", resp, tempo_ms);
    }

    return 0;
}
