#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(){
int i, a, b, c, t, v[2];
t=1;
while(t!=0){
scanf("%d %d", &a, &b);
if(a==0)break;
v[0]=a;
c=0;
for(i=0;i<b;i++){
    scanf("%d", &v[1]);
    if(v[1]<v[0])c=c+(v[0]-v[1]);
    v[0]=v[1];
}
printf("%d\n",c);
t=a;
}
return 0;
}

