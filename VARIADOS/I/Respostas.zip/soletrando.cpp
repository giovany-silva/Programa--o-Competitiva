#include <cstdio>
#include <cstring>

int main()
{
	char teclado[10][5] = {" ", "", "abc", "def", "ghi",  "jkl", 
						  "mno", "pqrs", "tuv", "wxyz"};

	char frase [1001];
	int n, tecla, ult_tecla = -1;
	bool found_it;

	scanf("%d ", &n);

	for(int i = 0; i < n; i++)
	{
		gets(frase);
		tecla = 0;

		// inicia impressao
		printf("Case #%d: ", i+1);

		for(int letra = 0; letra < strlen(frase); letra++) // navega letra a letra na frase
		{			
			for(int l = 0; l < 12; l++) // verifica se está em cada tecla
			{
				found_it = false;
				for(int c = 0; c < strlen(teclado[l]); c++) // em qual posição da tecla
				{
					if(frase[letra] == teclado[l][c])
					{
						if(ult_tecla == l) // anterior terminou com a mesma tecla, precisa dar espaço
							printf(" ");
						for(int r = 0; r <= c; r++)
							printf("%d", l); // imprimo a tecla atual o numero de vezes = posicao na tecla
						ult_tecla = l;
						found_it = true;
						break;
					}
				}

				if(found_it) break;
			}			
		}

		// acaba de imprimir
		printf("\n");
	}

	return 0;
}