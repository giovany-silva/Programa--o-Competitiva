#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1e9 + 7;
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define INF 0x3f3f3f3f
#define INFLL 0x3f3f3f3f3f3f3f3fLL
#define MAXN 100001
typedef long long int ll;
typedef pair<int,int> pii;
typedef vector <int> vi;

int main(){
	int n, k, x;
	vector <pii> v;
	while(1){
		scanf("%d %d", &n, &k);
		if(n==0 && k==0) break;
		v.clear();
		for(int i=0;i<n;i++){
			scanf("%d", &x);
			v.pb(mp(x,i+1));
		}
		sort(v.begin(), v.end());
		int mind = INF, ini = INF;
		/*for(int i=0;i<n;i++){
			printf("%d ", v[i].f);
		}
		printf("\n");*/
		for(int i=0;i+k-1<n;i++){
			if(mind > v[i+k-1].f-v[i].f){
				//printf("%d\n", i);
				mind = v[i+k-1].f-v[i].f;
				ini = i;
			}	
		}

		printf("%d : ", mind);
		vi ans;
		for(int i=0;i<k;i++){
			ans.pb(v[ini+i].s);
		}
		sort(ans.begin(), ans.end());
		int tam = ans.size();
		for(int i=0;i<tam;i++){
			printf("%d", ans[i]);
			if(i != tam-1) printf(" ");
		}
		printf("\n");
	}
}

