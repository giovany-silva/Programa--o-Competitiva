#include <bits/stdc++.h>
using namespace std;

int main(){
	int v, t, n, j;
	cin >> n;
	while(n--){
		cin >> v >> t;
		for(int i=0; i<t; i++){
			cin >> j;
			v+=j;
			if(v>100)
				v=100;
			if(v<0)
				v=0;
		}
		cout << v << endl;
	}
	
	return 0;
}