/*
 * Preocupado.
 * Solução sem fórmula fechada para teste de tempo.
 * O problema calcula a série: 2 + 6 + 10 + ... + (4n-2) = 2n^2
 * abril de 2014
 */

#include <stdio.h>

int main()
{
  long long min, casos;
  long long ans;

  scanf("%lld",&casos);

  for (int i=0; i<casos; i++) {
    scanf("%lld",&min);
    ans = (2*min*min);
    printf("%lld\n", ans);
  }

  return 0;
}
