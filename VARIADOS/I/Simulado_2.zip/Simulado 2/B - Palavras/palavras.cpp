#include<iostream>
#include<string>
#include<map>
#include<queue>

using namespace std;

map<string, int> mapa;

void gerar_palavras(){
    queue<string> lista;
    string s = "";

    for(char c = 'a'; c <= 'z'; c++)
      lista.push(s+c);

    int cont = 1;

    while(!lista.empty()){
        s = lista.front();
        lista.pop();

        mapa.insert(make_pair(s, cont));
        cont++;

        if(s.size() == 5) continue;

        for(char c = s[s.size()-1]+1; c <='z'; c++)
          lista.push(s + c);
    }
}

int main(){

    map<string, int>::iterator it;
    string s;

    gerar_palavras();

    while(cin >> s){
        it = mapa.find(s);
        if(it == mapa.end())
          cout << 0 << endl;
        else
          cout << it->second << endl;
    }

    return 0;
}
