#include <cstdio>
using namespace std;

int main() {
	int TC;
	long long a, n, p, f;

	scanf("%d", &TC);

	while (TC--) {
		long long ans = 0;
		scanf("%lld", &f);
		for (int i = 0; i < f; i++) {
			scanf("%lld %lld %lld", &a, &n, &p);
			ans += a * p;
		}
		printf("%lld\n", ans);
	}

	return 0;
}
