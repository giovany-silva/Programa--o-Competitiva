#include<stdlib.h>
#include<stdio.h>
void main()
{
    int a,b;
    scanf("%d %d",&a,&b);

    verifica(a,b);
}
int verifica(int a,int b)
{
    if(a>=b){printf("%d \n %d",b,a);}
    else{printf("%d \n %d",a,b);}
}