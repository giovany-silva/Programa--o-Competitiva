#include<stdlib.h>
#include<stdio.h>
void imprime();
int main()
{
  imprime();
}
void imprime()
{
  printf("Curso Sistemas de Informação \n");
printf("Disciplina – Fundamentos de Programação\n");
printf("Universidade Federal de Itajubá\n");
}