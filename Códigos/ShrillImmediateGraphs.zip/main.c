#include<stdlib.h>
#include<stdio.h>
int facasoma(int a, int b);
int  main()
{
  int soma,a,b;
  scanf("%d %d",&a,&b); 
      
soma=facasoma(a,b);
printf("%d",soma);
return 0;
}
 int facasoma(int a, int b)
 {int soma;
   soma=a+b;
   return soma;
 }
 