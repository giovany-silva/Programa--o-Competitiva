#include<stdlib.h>
#include<stdio.h>
int main()
{
for(i=0;i)

}
int media ()
{

}