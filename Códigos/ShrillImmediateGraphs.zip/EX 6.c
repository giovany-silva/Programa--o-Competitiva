
#include<stdlib.h>
#include<stdio.h>
int media (int v[])
{
    int i,a;
      a=0;
for(i=0;i<10;i++)
{
    a=a+v[i];
    
}
printf("%d",v[i]);

}

int main()
{ 
    int i,v[10];
for(i=0;i<10;i++)
{
   printf("PLEASE %i ""VALUES\n",10-i);
    scanf("%d",&v[10]);
    
}
media(v[10]);


}