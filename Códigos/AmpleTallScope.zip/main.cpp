#include<bits/stdc++.h>
using namespace std;
vector<int>divisores;
void listar_divisores(int n);
int mdc(int num1, int num2) {

    int resto;

    do {
        resto = num1 % num2;

        num1 = num2;
        num2 = resto;

    } while (resto != 0);

    return num1;
}
int mmc(int num1,int num2){


return (num1*num2)/mdc(num1,num2);
}


int main() {
 int i,j,t;

  cin>>t;

  for(i=0;i<t;i++){
  int num_divisores,fator,qtd;
  long long num=1;
  long long soma=0;

	    cin>>num_divisores;
	    for(j=0;j<num_divisores;j++){
	     cin>>fator>>qtd;

	     num*=pow(fator,qtd);
	     
	     

	    }
        int k;


	   for( k=1;k <=num;k++){
	      for(j=k+1;j<=num;j++){
	       
		if(mmc(k,j)==num){
		 soma+=k+j;
	  
		}

	      }
	 
	   }
    cout<<soma<<endl;
   

  }

    return 0;
}


void listar_divisores(int n){
    
    int a=1;
    
    
    while(a<n/a){
        if(n%a==0){
            
            divisores.push_back(a);
            divisores.push_back(n/a);
        }a++;
    }
    if(n/a==a)divisores.push_back(a);
}

