#include <bits/stdc++.h>

using namespace std;

string func(int h,int n,int m){
  cout<<h<<endl;
  if(n > 0){
    return func(floor(h/2)+10,n--,m);
  }else if(m > 0){
    return func(h-10,n,m--);
  }else{
    return ((h > 0) ? "NO":"YES");
  }
}

int main() {

int t,h,n,m;

cin>>t;
for(int i=0;i<t;i++)
{
  cin>>h>>n>>m;
  cout<<func(h,n,m)<<endl;
}  
  return 0;
}

