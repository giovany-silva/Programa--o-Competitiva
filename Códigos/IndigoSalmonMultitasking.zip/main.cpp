#include<bits/stdc++.h>
#include<unistd.h>
using namespace std;

struct estado
{ 

    int macaco;//posicao do macaco
    int graveto;//posicao do graveto

    int caixa;//posicao da caixa

    bool sobe_caixa;//variavel para indicar se o macaco subiu na caixa
    bool possuiGraveto;// variavel para indicar se possui graveto
    bool possuiBanana;// variavel para indicar se possui banana

    int acao;
    int valor;

};


// armazena de acordo com os valores. Menores valores tem
// maior prioridade

#define MAXIMO 1024

vector<estado>vetor(MAXIMO);

int ContadorItens = 0; 

bool Vazia(){
   if( ContadorItens == 0)
   return true;
   return false;

}

void inserir(struct estado dado){//inserir no vetor de estados

    int it = 0;

    // insere dado se a fila tiver vazia 

    if(ContadorItens == 0){

        vetor[ContadorItens++] = dado;        

    }else{

        // começa do final da fila
			
    for(it = ContadorItens - 1; it >= 0; it-- ){

        // se os dados forem grandes, joga o item no final

        if(dado.valor < vetor[it].valor){

               vetor[it+1] = vetor[it];

        }else{

            break;

        }            

    }  

    // inserir dado 

    vetor[it+1] = dado;

    ContadorItens++;

    }

}

struct estado removerDados(){

   return vetor[ContadorItens--]; 

}

struct estado geraEst(int macaco, int graveto,int caixa,bool sobe_caixa, bool possuiGraveto, bool possuiBanana) 

{ 

    struct estado e;

    e.macaco = macaco;

    e.graveto = graveto;

    e.caixa = caixa;

    e.sobe_caixa = sobe_caixa;

    e.possuiGraveto = possuiGraveto;

    e.possuiBanana = possuiBanana;

    e.acao = 0;

    e.valor = 0;

    return e; 

}

//calcula o alcance do macaco
int calcula_alcance(struct estado e, struct estado objetivo)
{

  int guarda=0;

  if (e.macaco == objetivo.macaco) guarda++;

  if (e.macaco == e.graveto && !e.possuiGraveto) guarda++;

  if (e.caixa == objetivo.caixa) guarda++;

  if (e.sobe_caixa == objetivo.sobe_caixa) guarda++;

  if (e.possuiGraveto == objetivo.possuiGraveto) guarda++;

  if (e.possuiBanana == objetivo.possuiBanana) guarda++;

  return guarda;

}

void imprimeEstado(struct estado est)

{

    printf("Localização do Macaco =  %d\n Localização do bastão = %d\nLocalização da caixa = %d\nEm cima da_caixa = %d\nPossui bastão = %d\nPossui banana = %d\n\n",

            est.valor, est.macaco, est.graveto, est.caixa, est.sobe_caixa, est.possuiGraveto, est.possuiBanana);

}


struct estado move(struct estado est, int acao, int pos)

{
    //acao = -2 filho nao entra na fila
    //acao = 1 macaco anda
    //acao = 2 macaco empurra caixa
    //acao = 3 macaco sobe na caixa
    //acao = 4 macaco bate com o bastao no cacho
    //acao = 5 macaco pega o cacho
    switch (acao)

    {

        case 1:

            if (!est.sobe_caixa && est.macaco != pos)

            {

                est.macaco = pos;

                return est;

            }

            else

            {   

                est.acao = -2;

                return est;

            } 

        break;

        case 2:

            if (!est.sobe_caixa && est.macaco == est.caixa && est.macaco != pos && est.caixa !=pos)

            {

                est.macaco = pos;

                est.caixa =pos;

                return est;

            }

            else

            {   

                est.acao = -2;

                return est;

            }

        

        case 3:

            if (!est.sobe_caixa && est.macaco == est.graveto && !est.possuiGraveto)

            {

                est.possuiGraveto = true;

                return est;

            }

            else

            {   

                est.acao = -2;

                return est;

            }

        

        case 4:

            if(!est.sobe_caixa && est.macaco == est.caixa)

            {

                est.sobe_caixa = true;

                return est;

            }

            else

            {   

                est.acao = -2;

                return est;

            }



        case 5:

            if (est.sobe_caixa && est.macaco == -1 && est.caixa == -1 && est.possuiGraveto && !est.possuiBanana)

            {

                est.possuiBanana = true;

                return est;

            }

            else

            {   

                est.acao = -2;

                return est;

            }

    }

}

// posicoes e ações do macaco 
struct estado resolve(struct estado resultado, struct estado goal)

{

    inserir(resultado);

    while(!Vazia())

    {

        struct estado maior = removerDados();

        imprimeEstado(maior);

        sleep(1);

        if(maior.possuiBanana)

        {

            return maior;

        }

        struct estado filho;

        //macaco anda

        int i;

        for(i=-1;i<4;i++)

        {    

            if (i != 0)

            {

                filho = move(maior, 1, i);

                filho.valor = calcula_alcance(filho, goal);

                if(filho.acao!=-2)

                    inserir(filho);

            }

        }

        //macaco empurra caixa

        for(i=-1;i<4;i++)

        {    

            if (i != 0)

            {

                filho = move(maior, 2, i);

                filho.valor = calcula_alcance(filho, goal);

                if(filho.acao!=-2)

                    inserir(filho);

            }

        }

        //macaco sobe na caixa

        filho = move(maior, 4, 0);

        filho.valor = calcula_alcance(filho, goal);

        if(filho.acao!=-2)

            inserir(filho);


        //macaco bate com o bastao no cacho

        filho = move(maior, 3, 0);

        filho.valor = calcula_alcance(filho, goal);

        if(filho.acao!=-2)

            inserir(filho);


        //pega o cacho

        filho = move(maior, 5, 0);

        filho.valor = calcula_alcance(filho, goal);

        if(filho.acao!=-2)

            inserir(filho);

    }

}

int main() 

{   

    struct estado est;

    est = geraEst(1, 2, 3, false, false, false);

    struct estado goal;

    goal = geraEst(-1, 2, -1, true, true, true);

    est.valor = calcula_alcance(est, goal);

    resolve(est, goal);

    return 0; 

} 