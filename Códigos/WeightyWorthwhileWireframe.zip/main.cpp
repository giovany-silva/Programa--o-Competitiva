#include<bits/stdc++.h>
using namespace std;

int main()
{

  string s,t;
  int n;

  cin>>n;
for(int k=0;k<n;k++){

    cin>>s>>t;

    int tam=s.size();
    string s_aux="",t_aux="";
    vector<bool>jah(tam,false);
    int qtd=0;
    bool possivel=true;
    int tam2=0;
    for(int i=0;i<tam;i++){
       if(s[i]!=t[i]){
          s_aux+=s[i];
          t_aux+=t[i];
          tam2++;
       }
    }

    for(int i=0;i<tam2;i++){
     if(jah[i])continue;
       for(int j=i+1;j<tam2;j++){
         if(jah[j])continue;
          if(s_aux[i]!=s_aux[j]&&s_aux[i]==t_aux[j]&&s_aux[j]==t_aux[i]){
          if(s_aux[i]=='?'||s_aux[j]=='?')continue;
           char aux=s_aux[j];
           s_aux[j]=s_aux[i];
           s_aux[i]=aux;
           jah[j]=true;
           jah[i]=true;
           qtd++;
          }

       }

    } 

    for(int i=0;i<tam2;i++){
       if(s_aux[i]=='1'&&s_aux[i]!=t_aux[i]){
          possivel=false;
          break;
       }
       else if(s_aux[i]!=t_aux[i]){
         qtd++;
       }
       

    }
 cout<<"Case "<<(k+1)<<": ";
  if(possivel)cout<<qtd;
  else cout<<"-1";
  cout<<endl;
  }
    

  return 0;

}