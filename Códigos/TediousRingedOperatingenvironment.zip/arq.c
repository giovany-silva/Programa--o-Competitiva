#include<stdlib.h>
#include<stdio.h>
#define L 20
#define C 5

int main()
{
  int i,j,nota_aluno,soma_classe,M[L][C];
  char nome[L][15];

  for(i=0;i<L;i++)
  {
    printf("PLEASE DIGIT THE STUDANT NAME...\n");
    scanf("%s", nome[i]);   // scanf("%s%*c", &nome[i]);

    for(j=0;j<C;j++)
    {
      printf("PLEASE DIGIT THE %i ""ª STUDANT NOTE",j+1);
      scanf("%d",&M[i][j]);
    }      
    
  }
  soma_classe=0;

  for(i=0;i<L;i++)
  {
    nota_aluno=0;
    for(j=0;j<C;j++)
    {
      nota_aluno=M[i][j]+nota_aluno;
      printf("A MEDIA DO ALUNO: %s", nome[i]);

      printf(" foi: %d",nota_aluno/5);

      if(nota_aluno/5>=5){
        printf("ALUNO APROVADO..\n");
      }
      else if(nota_aluno/5<5&&nota_aluno/5>=4)
      {
        printf("ALUNO EM EXAME...\n");
      }
      else
      {
        printf("ALUNO REPROVADO...\n");
      }
    }
    soma_classe=nota_aluno+soma_classe;
  }

  printf("A MEDIA DA CLASSE EH:",soma_classe/75);
}
