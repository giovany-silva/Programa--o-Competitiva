import matplotlib.pyplot as plt
import numpy as np


N_MAX = 100  # Quantidade de iterações
q = 4  

n = 0.01  # Taxa de aprendizado.
nEntrada = 2  # Número de neurônios na camada de entrada.
nEscondido = 1  # Número de neurônios na camada escondida.
nSaida = 1  # Número de neurônios na camada de saída.

# Amostra para treinamento
x1 = np.array(
    [0 , 0 , 1 , 1])
x2 = np.array(
    [0 , 1  , 0 , 1])

# Saida desejada
d = np.array([-1 , 1 , 1 , -1])

# Pesos de forma Aleatoria
W1 = np.random.random((nEscondido, nEntrada + 1))
W2 = np.random.random((nSaida, nEscondido + 1))

# Array para amazernar os erros.
E = np.zeros(q)
Etm = np.zeros(N_MAX)

# bias
bias = 1

# Entrada do Perceptron.
X = np.vstack((x1, x2))  #"junta"x1 e x2 ( empilha )


for i in range(N_MAX):
    for j in range(q):

        # Insere o bias no vetor de entrada.
        Xb = np.hstack((bias, X[:, j]))

        # Saída da Camada Escondida.
        O1 = np.tanh(W1.dot(Xb))  

        # Incluindo o bias. Saída da camada escondida é a entrada da camada
        # de saída.
        O1b = np.insert(O1, 0, bias)

        # Neural network output
        Y = np.tanh(W2.dot(O1b))  

        e = d[j] - Y  # Equação (5).

        # Erro Total.
        E[j] = (e.transpose().dot(e)) / 2  

        # Error backpropagation.
        # Cálculo do gradiente na camada de saída.
        delta2 = np.diag(e).dot((1 - Y * Y))  # Eq. (6)
        vdelta2 = (W2.transpose()).dot(delta2)  # Eq. (7)
        delta1 = np.diag(1 - O1b * O1b).dot(vdelta2)  # Eq. (8)

        # Atualização dos pesos.
        W1 = W1 + n * (np.outer(delta1[1:], Xb))
        W2 = W2 + n * (np.outer(delta2, O1b))

    Etm[i] = E.mean()




ErrorT = np.zeros(q)

for i in range(q):
    # Insere o bias no vetor de entrada.
    Xb = np.hstack((bias, X[:, i]))

    # Saída da Camada Escondida.
    O1 = np.tanh(W1.dot(Xb))  

    # Incluindo o bias. 
    O1b = np.insert(O1, 0, bias)

 
    Y = np.tanh(W2.dot(O1b)) 

    ErrorT[i] = d[i] - Y

print(ErrorT)
print(np.round(ErrorT) - d)
plt.plot(Etm)
plt.show()