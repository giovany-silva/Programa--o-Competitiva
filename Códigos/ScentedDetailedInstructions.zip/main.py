import queue as Queue
bestList=[]
class Node:
    def __init__(self,level,value,weight,bound,content):
        self.level=level # The level within the tree
        self.value=value # The total value
        self.weight=weight # The total weight
        self.bound=bound   # max (optimistic) value one node can take
        self.content=content   # list of items of node

def get_Bound(u,numberItems,capacity,weights,value):
    if u.weight>=capacity:
        return 0
    else:
        upperBound=u.value
        totalWeight=u.weight
        j=u.level+1
        if j<numberItems:
            upperBound=upperBound+(capacity-totalWeight)*value[j]/weights[j]
        return upperBound 

def solve_Knapsack(weights,values,capacity):
    numberItems=len(weights)
    queue=Queue.PriorityQueue()
    root=Node(-1,0,0,0.0,[])   
    queue.put((0,root))

    maxvalue=-1
    bound=0
    while not queue.empty():
        v=queue.get()[1] # Get the next item on the queue
        if(v.bound>maxvalue and v.level<numberItems-1):
            uLevel=v.level+1 
            u=Node(uLevel,v.value+values[uLevel],v.weight+weights[uLevel],0,v.content[:])
            u.content.append(uLevel)
            bound=get_Bound(u,numberItems,capacity,weights,values)
            u.bound=bound

            if (u.weight<=capacity and u.value>maxvalue):
                # Is this the best solution?
                maxvalue=u.value
                global bestList 
                bestList=u.content[:]

            if bound>maxvalue:    
                # Should this solution be considered?
                queue.put((-u.bound,u))

            u = Node(uLevel,v.value,v.weight,0.0,v.content)
            bound = get_Bound(u,numberItems,capacity,weights,values)
            u.bound=bound
            if (bound>maxvalue):
                queue.put((-u.bound,u))
            
    return maxvalue,bestList


if __name__ == '__main__':


    #  Please, sort the items by value/weight
    ref_arquivo = open("ks_400_0","r")

    weightList=[]
    valueList=[]

    for linha in ref_arquivo:
          valores = int(linha)
          valueList.append(valores)
          valores = int(linha)
          weightList.append(valores)

    ref_arquivo.close()

    capacity=10



    print (solve_Knapsack(weightList,valueList, capacity))