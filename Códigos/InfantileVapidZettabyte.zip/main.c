
#include<stdlib.h>
#include<stdio.h>
int main()
{int i,j,nota[15][3];
  char nome[i][15];
  for(i=0;i<15;i++)
  {printf("PLEASE DIGIT THE STUDANT NAME...\n");
    scanf(" %s",&nome[i][15]);
    
  printf("INCREASE THE NOTES...\n");
     for(j=0;j<5;j++)
    { scanf("%d",&nota[i][j]);

    }
  } int st=0; 
  for(i=0;i<15;i++)
  {int s=0;
    printf("%d",nome[i][15]);
    for(j=0;j<5;j++)
    {
      s=nota[i][j]+s;
      printf("%d",s);}
      if(s/5>=5){printf("CONGRATULATIONS...\n");}
      else if(s<5&&s>=4){printf("IN TEST...");}
      else{printf("REPROVED...");}
      st=s+st;
    }
  printf("THIS CLASS MIDDLE %d",st/5);
  
}