#include <iostream>
#include <vector>

using namespace std;
//algoritmo eficiente para encontar uma substring dentro de outra string
bool kmp(string texto, string padrao, vector<int> aux)
{
	int idx_texto = 0, idx_padrao = 0;

	while((unsigned)idx_texto < texto.size())
	{
		if(padrao[idx_padrao] == texto[idx_texto])
		{
			idx_padrao++;
			idx_texto++;
		}

		if((unsigned)idx_padrao == padrao.size())
		{
		  return true;	
			idx_padrao = aux[idx_padrao - 1];
		}

		if((unsigned)idx_texto < texto.size() &&
				padrao[idx_padrao] != texto[idx_texto])
		{
			if(idx_padrao)
				idx_padrao = aux[idx_padrao - 1];
			else
				idx_texto++;
		}
	}
  return false;
}

//funcao para criar o prefixo (vetor de acordo com a substring que eu quero)
//essa deve ser chamada antes da funcao para achar a substring
void prefix(string padrao, vector<int> & aux)
{
	aux[0] = 0;
	int j = 0, i = 1;

	while((unsigned)i < padrao.size())
	{
		if(padrao[i] == padrao[j])
		{
			j++;
			aux[i] = j;
			i++;
		}
		else
		{
			if(j)
				j = aux[j - 1];
			else
			{
				aux[i] = 0;
				i++;
			}
		}
	}
}

int main(int argc, char *argv[])
{
  int l,c,n;
  cin>>l>>c;
  string matriz[l];
 for(int i=0;i<l;i++){
    cin>>matriz[l];
 }
 cin>>n;
 string palavras[n];
 for(int i=0;i<n;i++){
   cin>>palavras[i];
 }

 for(int i=0;i<l;i++){
     for(int j=0;j<c;j++){
        string a="",c="",b="";
        a=matriz[i];
        for(int k=i;k<n;k++){
           b+=matriz[0][i]
        }
        for(int k=i;k<n;k++){
           b+=matriz[0][i]
        }
     }
 }
// for()

	string texto = "C++ eh mais do que legal, muito legal";
	string padrao = "legal";

	vector<int> aux(padrao.size());//vetor para armazenar o prefixo

	prefix(padrao, aux);
  if(kmp(texto, padrao, aux)){cout<<"tem\n";}

	return 0;
}
