#include<stdlib.h>
#include<stdio.h>
#include<string.h>

void imprimir(int l, int c, char x[][c][10])
{
  for(int i=0;i<l;i++)
  {
    for(int j=0;j<c;j++)
    {
      printf("%s ",x[i][j]);
    }
    printf("\n");
  }  
}

void preencher(int l, int c, char x[][c][10],char
v[])
{
  for(int i=0;i<l;i++)
  {
    for(int j=0;j<c;j++)
    {
     
if(i==j)
        {
        strcpy(x[i][j],"0");
        } else{
        strcpy(x[i][j],v);
      }
    }
  }

}

int main()
{

  int l,c,v;
  
  scanf("%d %d",&l,&c);

  char x[l][c][10];
  
  
  preencher(l, c, x, "888");
   
  imprimir(l, c, x); 

  return 0;
}
