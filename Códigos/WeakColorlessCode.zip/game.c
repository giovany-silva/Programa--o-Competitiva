
#include<stdlib.h>
#include<stdio.h>

void funcao_game_1();
void funcao_game_2();
void funcao_game_3();
int main()
{
  int i,j,d;
  printf("ESCOLHA SEU NÍVEL DE DIFICULADADE:\n\n");
printf("      =======================================================\n");
printf("      =======================================================\n");
printf("      =======================================================\n");
printf("      ||       1-INICIANTE                                 ||\n\n");
printf("      ||       2- MÉDIO                                    || \n");
printf("      =======================================================\n");
printf("      =======================================================\n");printf("      =======================================================\n");                                
do{scanf("%d",&d);}while((d!=1&&d!=2)&&d!=3);
switch(d)
{
  case 1:funcao_game_1();
 case 2:funcao_game_2();
case 3:funcao_game_3();
}

}
void funcao_game_1()
{
  int i,j,v[0];
  printf("\nO JOGO INCIARÁ APERTE QUALQUER TECLA PARA INCIAR\n");
  
  v[0]=1;
  for(i=1;i<10;i++){v[i]=v[i-1]*2+v[i];}
  for(i=0;i<9;i++)
  {
    printf("%d ",v[i]);
  }
  printf("QUAL SERA O ULTIMO NÚMERO");


}                                        
void funcao_game_2(){}
void funcao_game_3(){}