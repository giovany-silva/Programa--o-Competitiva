#include<bits/stdc++.h>
using namespace std;
#define TAM_GRAFO 8 //TAM ENTRADA
#define N_VERTICES 8
#define N_ARESTAS 11
std::stack<pair<vector<int>,vector<int>>>pilha;//PILHA DE ESTADOS(VERTICES NA CLIQUE/VERTICES QUE NAO ESTAO)
std::vector<int>Q,K;//estao /nao estao
bool grafo[TAM_GRAFO][TAM_GRAFO],clique[TAM_GRAFO];//GRAFO COM SUAS LIGACOES

void inicializa_grafo();
void inicializa_clique();
void adiciona_na_clique();
void adiciona_no_grafo(int x,int y);
void copia(vector<int>vet1,vector<int>vet2);
void atualiza_k(int v);
void adiciona_v(int v);
void cria_vet_vertices();
void le_entrada();
bool * retorna_vizinhos(int vert);
bool faz_parte(int vert);
int tam_clique();
int main()
{

inicializa_grafo();
inicializa_clique();
le_entrada();

cria_vet_vertices();

pilha.push(std::make_pair(Q,K));//inicializa a pilha de estados

while(!pilha.empty()){
  
          pair<vector<int>,vector<int>>auxiliar; //remove o estado do topo da pilha                   
        auxiliar=pilha.top();
        pilha.pop();
            
        copia(Q,auxiliar.first);//Q<= first 
        copia(K,auxiliar.second);//K<=second


  for(vector<int>::iterator it=Q.begin();it!=Q.end();it++)
  {
      cout<<*it<<" ";
      
  }
    for(vector<int>::iterator it=K.begin();it!=K.end();it++)
  {
      cout<<*it<<" ";      
      
  }

cout<<Q.size()<<K.size();
cout<<endl;
     while(K.size()!=0&&tam_clique()<Q.size()+K.size()){
               
                   vector<int>::iterator vert_dt=K.end();//deletou o  vértice v de K
                    K.pop_back();
                    pilha.push(make_pair(Q,K));//L 7
                   //se v está ligado com todos os vértices de Q ele é adicionado em Q
                   //obs : se clique vazia v eh adicionado, o "novo" K serah os vizinhos de v que 
                  //nao estao em Q 
                   adiciona_v(*vert_dt);//Passa o Q e vértice deletado de K
                 atualiza_k(*vert_dt);
                    
                }
                
                if(tam_clique()<Q.size()){
                     adiciona_na_clique();//atualiza clique
                }
               

                
}
//Printa a Clique

for(int i=0;i<N_VERTICES;i++)
{
    if(faz_parte(i))cout<<i<<" ";
    cout<<"\n"<<tam_clique();
}



return 0;
}
void copia(vector<int>vet1,vector<int>vet2)
{
    vet1.clear();
    for(vector<int>::iterator it=vet2.begin();it!=vet2.end();it++){
        
        vet1.push_back(*it);
        
    }
    
}
void adiciona_na_clique()
{
    inicializa_clique();//zerou clique
    vector<int>::iterator it ;
       
       for(it=Q.begin();it!=Q.end();it++)
       {
           clique[*it]=true;//atualiza a clique de acordo com a posicao
       }
    
}

void atualiza_k(int v)
{
    vector<int>::iterator it;
    bool *aux=retorna_vizinhos(v);
    sort(K.begin(),K.end());  
    
               //Verifica  os vértices de Q 
           for(it=K.begin();it!=K.end();it++) {
               //se v nao for vizinho de um vértice de Q sai do laço
                            if(!aux[*it]){//se nao for vizinho de v
                             K.erase(it);//deleta jah q nao eh vizinho de v
                            }
                                
           }
    
    
}
void adiciona_v(int v)
{  vector<int>::iterator it;
   bool esta=true;
   bool *aux=retorna_vizinhos(v);
   sort(Q.begin(),Q.end());    
   
   if(Q.empty()){
       
       Q.push_back(v);
       return;
   }
           //Verifica  os vértices de Q 
           for(it=Q.begin();it!=Q.end();it++) {
               //se v nao for vizinho de um vértice de Q sai do laço
                            if(!aux[*it]){//se nao for vizinho de v
                                esta=false;
                                break;
                            }
                                
           }
    
    if(esta){ 
        Q.push_back(v);
    }
    return;
}


int tam_clique(){
    int i=0,tam=0;
    
    while(i<N_VERTICES)
    {
        
        if(faz_parte(i))tam++;
        i++;
    }
    
return tam;    
}
//adiciona  os VERTICES  ao vetor K
void cria_vet_vertices()
{
    
    for(int i=0;i<N_VERTICES;i++){  
        K.push_back(i); //k[i]=i
        
    }
    
    

}
void le_entrada()
{
int i;

    for(i=0;i<N_ARESTAS;i++){
                             int x,y;
                             cin>>x>>y;
        
                             adiciona_no_grafo(x,y);
        
    }
    

}
void inicializa_clique()
{
int i;
	for(i=0;i<TAM_GRAFO;i++){
         		
                                clique[i]=false;
    }


}
void inicializa_grafo()
{
int i,j;
	for(i=0;i<TAM_GRAFO;i++){
         			for(j=0;j<TAM_GRAFO;j++){
                                grafo[i][j]=false;

                                }
        }


}
void adiciona_no_grafo(int x,int y)
{
grafo[x][y]=true;

}
//vai retornar vizinhos do vértices removidos que não estão na clique
bool * retorna_vizinhos(int vert)
{
  return grafo[vert];   
}

bool faz_parte(int vert)
{
    return clique[vert];
    
}

